

//- inherit elements & methods from UnitConverter.
public abstract class MassConverter extends UnitConverter {

	public MassConverter() {
	}

};
