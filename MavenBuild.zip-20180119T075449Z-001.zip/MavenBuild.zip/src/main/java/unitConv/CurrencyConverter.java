

//- inherit elements & methods from UnitConverter.
public abstract class CurrencyConverter extends UnitConverter {

	public CurrencyConverter() {
	}
};
