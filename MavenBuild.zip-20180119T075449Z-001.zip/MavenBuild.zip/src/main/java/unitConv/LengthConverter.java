

//- inherit elements & methods from UnitConverter.
public abstract class LengthConverter extends UnitConverter {

	public LengthConverter() {
	}
};