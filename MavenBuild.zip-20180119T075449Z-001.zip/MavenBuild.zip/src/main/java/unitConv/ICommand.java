
interface ICommand {

	public void executeCommand();

	public void setKey(String key);

	public void setValue(double numericValue);
}
